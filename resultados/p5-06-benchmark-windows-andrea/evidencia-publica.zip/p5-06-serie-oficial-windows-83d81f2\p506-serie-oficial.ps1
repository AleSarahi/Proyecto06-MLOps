# P5-06 (#86): serie oficial de Windows. UNA SOLA VEZ. Autorizada por Karen (2026-11-02, 20:22)
# en cuanto <REDACTED> publique en el PR el comentario con el hash del README.
# Correr desde una PowerShell aparte, con la laptop conectada, sin ahorro de bateria
# y con VS Code y OneDrive cerrados:
#   powershell -ExecutionPolicy Bypass -File C:\Users\<REDACTED>\p506-serie-oficial.ps1
$ErrorActionPreference = 'Stop'
$Commit = '83d81f262f8423e20832462e478222dc4129faa0'
$Expected = '0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1'
$HashReadme = '8eb90d88a7c413704aac93b1f6a6b9b91f1fb6d11fce0774a3d1a43f19ae0979'
$Repo = Join-Path $HOME 'P5-06-e75533f'
$Python = Join-Path $Repo '.venv\Scripts\python.exe'
$Weights = Join-Path $env:LOCALAPPDATA 'P5-05\yolo11n.pt'
$OutDir = Join-Path $Repo 'resultados\p5-06-benchmark-windows-andrea'
$BenchmarkPath = Join-Path $OutDir 'benchmark.json'
$Ev = Join-Path $HOME 'p506-serie-oficial'

# --- Condiciones antes de empezar (si algo falla aqui, no se ha medido nada) ---
if (Test-Path $OutDir) { throw "Ya existe $OutDir : la serie ya se corrio o se intento. No repetir; avisar a <REDACTED> y Karen." }
if (Test-Path $Ev) { throw "Ya existe $Ev : la serie ya se corrio o se intento. No repetir." }
$Comentarios = (gh pr view 86 --repo karenelizabg/Proyecto05-MLOPS --json comments --jq '.comments[].body') -join "`n"
if ($LASTEXITCODE -ne 0) { throw 'No se pudo consultar GitHub (gh). Revisa la conexion y vuelve a correr.' }
if (-not $Comentarios.Contains($HashReadme)) { throw '<REDACTED> aun no publica en #86 el comentario con el hash del README: Karen autorizo solo despues de eso.' }
$HeadPr = gh pr view 86 --repo karenelizabg/Proyecto05-MLOPS --json headRefOid --jq .headRefOid
if ($HeadPr -ne $Commit) { throw "El PR #86 ya no esta en $Commit (ahora $HeadPr). No correr: hay que revisar el commit nuevo." }
Set-Location $Repo
$HeadLocal = git rev-parse HEAD
if ($HeadLocal -ne $Commit) { throw "El clon esta en $HeadLocal, no en $Commit." }
if ((Get-FileHash -Algorithm SHA256 $Weights).Hash.ToLower() -ne $Expected) { throw 'El SHA-256 de los pesos no coincide.' }
$Bloqueantes = Get-Process -Name 'Code', 'Code - Insiders', 'OneDrive' -ErrorAction SilentlyContinue
if ($Bloqueantes) { throw "Cierra antes: $(($Bloqueantes | Select-Object -ExpandProperty ProcessName -Unique) -join ', ')" }

New-Item -ItemType Directory -Path $Ev | Out-Null
Start-Transcript -Path (Join-Path $Ev 'consola.txt') | Out-Null
try {
    "commit=$Commit"
    "inicio=$(Get-Date -Format o)"
    Get-CimInstance Win32_Battery | Select-Object BatteryStatus, EstimatedChargeRemaining | Format-List
    Get-CimInstance Win32_Processor | Select-Object Name, LoadPercentage | Format-List
    Get-Process | Sort-Object CPU -Descending | Select-Object -First 15 ProcessName, CPU, WorkingSet64 | Format-Table -AutoSize | Out-String -Width 200

    # --- La serie (seccion 3 de la guia de <REDACTED>) ---
    & $Python .\resultados\p5-06-benchmark.py --weights $Weights --output $BenchmarkPath --responsable Andrea
    $Codigo = $LASTEXITCODE
    "codigo_benchmark=$Codigo"
    if ($Codigo -ne 0) { throw 'serie oficial incompleta; conservar benchmark.json y benchmark.preflight.json si existen. NO repetir.' }

    $Benchmark = Get-Content -LiteralPath $BenchmarkPath -Raw | ConvertFrom-Json
    if ($Benchmark.muestras_ms.control.Count -ne 50 -or $Benchmark.muestras_ms.supervisado.Count -ne 50) { throw 'faltan muestras medidas' }
    if ($Benchmark.calentamientos_excluidos_ms.control.Count -ne 10 -or $Benchmark.calentamientos_excluidos_ms.supervisado.Count -ne 10) { throw 'faltan calentamientos excluidos' }
    if ($Benchmark.reinicios_medidos.Count -ne 50 -or $Benchmark.reinicios_excluidos.Count -ne 10) { throw 'faltan reinicios medidos o excluidos' }
    if (@($Benchmark.reinicios_medidos | Where-Object { $_.ready.estado -ne 'ready' -or $_.ready.model_sha256 -ne $Expected -or $_.ready.config_sha256 -ne '6428a259f22939fe5055dc101cec4517612dad5fb573d5852187932f39954e08' -or $_.ready.torch_threads -ne 2 }).Count -ne 0) { throw 'READY de reinicio invalido' }
    $DeltaP50 = $Benchmark.stats_ms.supervisado.p50 - $Benchmark.stats_ms.control.p50
    $DeltaP95 = $Benchmark.stats_ms.supervisado.p95_lineal - $Benchmark.stats_ms.control.p95_lineal
    "Delta p50=$DeltaP50 ms; Delta p95=$DeltaP95 ms; p95 supervisado=$($Benchmark.stats_ms.supervisado.p95_lineal); max supervisado=$($Benchmark.stats_ms.supervisado.max); sobre 500 ms=$($Benchmark.solicitudes_sobre_500_ms.supervisado)"
    if ($DeltaP50 -gt 5 -or $DeltaP95 -gt 10 -or $Benchmark.stats_ms.supervisado.p95_lineal -gt 150 -or $Benchmark.stats_ms.supervisado.max -gt 200 -or $Benchmark.solicitudes_sobre_500_ms.supervisado -ne 0) { throw 'al menos un limite de Karen no se cumplio; conservar evidencia completa. NO repetir.' }
    'RESULTADO: todos los limites de Karen se cumplen.'
}
catch {
    "ERROR: $($_.Exception.Message)"
}
finally {
    "fin=$(Get-Date -Format o)"
    if (Test-Path $OutDir) { Get-ChildItem -LiteralPath $OutDir -File | Get-FileHash -Algorithm SHA256 | Format-Table Hash, Path -AutoSize | Out-String -Width 300 }
    Stop-Transcript | Out-Null
    Write-Host "Listo. Evidencia: $OutDir y $Ev. No vuelvas a correr este script; avisale a Claude."
}
