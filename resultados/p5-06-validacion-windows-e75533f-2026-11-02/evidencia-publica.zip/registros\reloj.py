from infer.reloj import descripcion_reloj
print(descripcion_reloj())
assert "QueryPerformanceCounter" in descripcion_reloj()["implementacion"]